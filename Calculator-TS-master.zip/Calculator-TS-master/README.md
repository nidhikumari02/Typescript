
# typescript calculator
this calculator is the better and typescript version of the calculator in this repository: https://github.com/saman2007/Calculator

