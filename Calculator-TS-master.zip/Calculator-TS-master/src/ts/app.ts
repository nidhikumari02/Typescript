operatorsButton.forEach((element) => {
  element.addEventListener("click", onButtonClick);
});
